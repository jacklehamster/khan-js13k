window.portal='';
